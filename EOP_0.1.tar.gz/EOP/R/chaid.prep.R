# funksie om data vir CHAID gereed te maak:
# verander character na factor
# verwyder veranderlikkes metbaie min inskrywings
# verwyder veranderlikke met te veel faktorvlakke wat 
# nie regtig kategorieë is nie  (soos name, responsid ens)
# vull NA op waar moontlik

# 

prep.chaid <- function(df, relavent.idx){
	require(reporttools)
	non.factor.idx = as.integer(which(sapply(df, class)!="factor"))
	sick.non.factors  = relavent.idx[relavent.idx %in% non.factor.idx] 
	for (i in sick.non.factors) df[,i] = factor(df[,i], levels=0:1, labels=c("No","Yes"))
	not.ones = sapply(df[relavent.idx], function(x) length(levels(x))>1)
	relavent.idx = relavent.idx[not.ones] # drop variables with only one levels
	min.count = sapply(df[relavent.idx], function(x) sum(table(x)) > 20 & length(levels(x)) < 20 ) # identify low counts
	relavent.idx = relavent.idx[min.count]
	df = df[relavent.idx]
	for (i in 1:ncol(df)){
		df[,i] =  NAtoCategory(df[,i])
	}
	
	df
	}