# function create a vector of clean (i.e. remove letter at end) stand number 

# usage: ermelo=cleannr(ermelo,"mainplace_name","standnumber","surname") where ermelo is a df with 
cleannr=function(df,mainplace_name="mainplace_name",standvar="standnumber",surnamevar="surname"){
df$cleannr=splitnr(df[,paste(standvar)])
df$hh.ID=paste(df[,paste(mainplace_name)],df$cleannr,df[,paste(surnamevar)],sep="")
df=df[which(duplicated(df$hh.ID)==FALSE),]
df
}

# base.number function # find original stand of subdivided stands write with / or . 
base.number=function(x){
 	patt='(^[[:digit:]]+)(\\/?)(\\.?)(\\-?)([[:alnum:]]*)'
 	gsub(patt,'\\1',x)
 	}
 	
isolate.number=function(x){
	patt <- '(^[[:alpha:]]*)(\\/?)(\\.?)(\\-?)([[:blank:]]*)([[:digit:]]+)([[:blank:]]*)([[:punct:]]*)([[:alpha:]]*)([[:blank:]]*)([[:punct:]]*$)'
	gsub(patt,'\\6',x)
} 	

isolate.name=function(x){
	patt <- '(^[[:alpha:]]*)(\\/?)(\\.?)(\\-?)([[:blank:]]*)([[:digit:]]+)([[:blank:]]*)([[:alpha:]]*)([[:punct:]]*)([[:alpha:]]*)([[:blank:]]*)([[:punct:]]*$)'
	gsub(patt,'\\1 \\8',x)
} 

# base.number function # find original stand of subdivided stands write with / or . 
letter.number=function(x){
 	patt='(^[[:alpha:]]{1})(\\/?)(\\.?)(\\-?)([[:blank:]]*)([[:digit:]]+)([[:blank:]]*)([[:punct:]]*)([[:alpha:]]*)([[:blank:]]*)([[:punct:]]*$)'
 	gsub(patt,'\\1\\6',x)
 	}

