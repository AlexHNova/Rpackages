####################################################################
#  Funksies on chi-kwadraat toets in massa toe doen                #
#                                                                  #
#                                                                  #
#                                                                  #
# (c) Nova Institute 2013                                          #
####################################################################

chi.bulk <- function(df, fn="chi.filename.tex"){
  # Identifiseer kategoriese veranderlikes op tipe en aantal kategorieë
  df.cat = df [, select.cat.vars(df)]
  # Pas die chi-toets funksie oor alle kombinasies van die lys toe
  for(i in 1: length(df.cat)) chi.test.list = lapply(df.cat, function(x) chi.tab(df[i], x) )
  # Skryf die data en resultate uit
  chi.test.list
}

####################################################################
#  Funksie on relevante veranderlikkes vir die massa chi-kwadraat  #
#  toets te kies.Gebruik die data-tipe en die aantal faktor-vlakke #
#  Gee by verstek 'n vektor van die indekse as uitvoer             #
####################################################################

select.cat.vars <- function(df, k = 8){
  # Maak 'n vektor van data-tipes
  classes = sapply(df, class)
  # Selekteer slegs dié wat kategories is en minder as 'n maksimum aantal faktor-vlakke het
  fac.idx = which(classes == "factor" &
    sapply(df[,names(classes)],function(x) length(levels(x))) <= k &
    sapply(df[,names(classes)],function(x) length(levels(x))) >= 2 )
  fac.idx
  # filter 'truisms' uit (patrone a.g.v vraelys programering: soos dat net vroue
  # geboorte kan gee). in so 'n geval is die chi2 waarde Inf en p=0
}

#################################################################################
# Funksie om alle moontlike kombinasies van geselekteerde veranderlikes te maak # 
#################################################################################
combn.formula <- function(fac.idx){
mtr = combn(names(fac.idx),2)
# test for pairs that have less than 2 levels and remove
form.list = apply(t(mtr),1, function(x)  paste(x[1],"~", x[2],sep=""))

#lapply(form.list, function(x) chiSquare(formula=as.formula(x), data=df ))
}

####################################################################
#  Funksie om geformateerde chi-kwadraat toets-uitslag te maak     #
####################################################################

chi.tab <- function(x, y){
res = chisq.test(table(x, y))
res.df = data.frame(Chisquare.value = res$statistic, 
                    Degrees.of.freedom = res$parameter,
                    p.value = res$p.value)
res.df # gee dit nog goeie ry en kolom name dat mens kan wees wat is wat
}
