###########################################################################
# Function to clean names of datasets made with the sticher function from #
# new Clyral csv fromat                                                   #
# use : x <- clean.stitch.names(x)                                                  #
# (c) Nova Institue 2013                                                  #      
###########################################################################

clean.stitch.names <- function(x){
 #Remove .y 
  dropidx = grep("\\.y$", names(x))
  x = x[-dropidx]
 #Remove x.  and .x 
 names(x) = gsub("^x\\.", "", names(x)) 
 names(x) = gsub("\\.x$", "", names(x))
 x
}