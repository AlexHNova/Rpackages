###########################################################
# Paarsgewyse Chi2 toetse en CHAID
# maak staat op chi.2.exp en spdf funksie 
#
###########################################################

chi.chaid <- function(x, naam = "HH_chi2_uitkomste", datadirr = datadir, grafdirr = grafdir, tabdirr = tabdir, p.cutofff = 0.01, plott = TRUE, nett.naam = "HH_chi2_uitkomste.net"){

chi.2.eksp(data = x, 
           plot=plott,
           p.cutoff= p.cutofff,
           out.idx = as.integer(which(sapply(x, class) == "factor")), 
           outdir = datadirr, 
           xlsx.name = paste(naam, sep=""), net.name = nett.naam)
message("spdf gemaak")

lapply(get("spdf", envir = .GlobalEnv), function(x) afh.tab(x, tabdir=tabdirr))
message("Afhanklikheidstabelle gemaak")

chaid.qol.list <- lapply(spdf, make.formula.c2m)
message("Fromule-lus gemaak")
qol.chaidlist <- lapply(chaid.qol.list, function(i) chaid(i, data=x))
#qol.shortform <- lapply(qol.chaidlist, get.short.form.chaid, type = "right")

save(x, spdf, chaid.qol.list, qol.chaidlist, 
     #qol.shortform, 
     file=paste(datadir, naam, ".Rda", sep=""))

lapply(seq_along(qol.chaidlist), function(i) {
  pdf(file=paste(grafdirr, names(qol.chaidlist[i]),"CHIAD.pdf", sep=""),width=21, height=18)
  plot(qol.chaidlist[[i]], main = names(qol.chaidlist[i]))
  message(names(qol.chaidlist[i]))
  dev.off()
})
assign("qol.chaidlist", qol.chaidlist, envir=.GlobalEnv)
assign("qol.shortform", qol.shortform, envir=.GlobalEnv)
}
