#### cl.alt.text

cl.alt.text <- function(x = cl.alt, decimals = 4, est = "users of the alternative ignition techinque"){
  aanloop = "The difference between the point estimate and the lower bound of the 90\\% confidence interval of "
  if (x[1, "point prop."] < 0.5){
    x = 1 - x
    inv = TRUE
  } 
   
  x = x[1,match(c("low prop.","point prop." ,"high prop."), dimnames(x)[[2]])]
  verskil = round(abs(x[2] - x[1]) * 100, decimals)
  tien = (x[2]*100)/10
  gk = ifelse(verskil < tien, "smaller", "larger")
  yn = ifelse(gk=="smaller", "", " not ")
  do.call("cat", list(sprintf("%s %s %s %s %.2f, %s %s %s %.2f %s %s %s" ,
         aanloop, 
         ifelse(inv==TRUE, "the inverse proportion of ", "the proportion of "), 
         est, 
        " is ", 
         verskil,
         "\\%. This is ", 
         gk , 
         " than 10\\% of ", 
         round(x[2]*100, decimals) ,
         "\\%. It is therefore", 
         yn , 
        " permissible to use the central estimate.")))
}